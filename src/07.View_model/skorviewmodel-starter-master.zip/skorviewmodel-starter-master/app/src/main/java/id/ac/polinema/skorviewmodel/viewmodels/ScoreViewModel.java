package id.ac.polinema.skorviewmodel.viewmodels;

import androidx.lifecycle.ViewModel;

public class ScoreViewModel extends ViewModel {

}

